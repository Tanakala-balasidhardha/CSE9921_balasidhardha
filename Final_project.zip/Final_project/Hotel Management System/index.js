// Entry point: load server
require('./server');
