const mongoose = require('mongoose');

const TableSchema = new mongoose.Schema({
  number: { type: Number, required: true, unique: true },
  seats: { type: Number, default: 4 },
  status: { type: String, enum: ['free', 'occupied'], default: 'free' },
  currentOrder: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' }
});

module.exports = mongoose.model('Table', TableSchema);
