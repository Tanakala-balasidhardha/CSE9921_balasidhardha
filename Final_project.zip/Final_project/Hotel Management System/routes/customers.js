const express = require('express');
const router = express.Router();
const Customer = require('../models/Customer');
const Order = require('../models/Order');

// create customer (no signup flow)
router.post('/', async (req, res) => {
  const { name, email } = req.body;
  if (!name) return res.status(400).json({ message: 'name required' });
  const c = new Customer({ name, email });
  await c.save();
  res.status(201).json(c);
});

// list customers
router.get('/', async (req, res) => {
  const list = await Customer.find();
  res.json(list);
});

// get customer with orders
router.get('/:id', async (req, res) => {
  const c = await Customer.findById(req.params.id).populate({ path: 'visits', populate: { path: 'items.menuItem' } });
  if (!c) return res.status(404).json({ message: 'Customer not found' });
  // also fetch orders
  const orders = await Order.find({ customer: c._id }).populate('items.menuItem');
  res.json({ customer: c, orders });
});

module.exports = router;
