const express = require('express');
const router = express.Router();
const MenuItem = require('../models/MenuItem');

// List menu
router.get('/', async (req, res) => {
  const items = await MenuItem.find();
  res.json(items);
});

// Create menu item
router.post('/', async (req, res) => {
  const { name, description, price, available } = req.body;
  const item = new MenuItem({ name, description, price, available });
  await item.save();
  res.status(201).json(item);
});

// Update
router.put('/:id', async (req, res) => {
  const item = await MenuItem.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(item);
});

// Delete
router.delete('/:id', async (req, res) => {
  await MenuItem.findByIdAndDelete(req.params.id);
  res.status(204).end();
});

module.exports = router;
