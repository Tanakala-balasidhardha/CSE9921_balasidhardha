const express = require('express');
const router = express.Router();
const Table = require('../models/Table');
const Order = require('../models/Order');

// list tables
router.get('/', async (req, res) => {
  const tables = await Table.find().populate('currentOrder');
  res.json(tables);
});

// check availability
router.get('/status', async (req, res) => {
  const total = await Table.countDocuments();
  const occupied = await Table.countDocuments({ status: 'occupied' });
  res.json({ total, occupied, allFilled: total > 0 && occupied >= total, freeTables: total - occupied });
});

// occupy a table (attach order id)
router.post('/:id/occupy', async (req, res) => {
  const { orderId } = req.body;
  const table = await Table.findById(req.params.id);
  if (!table) return res.status(404).json({ message: 'Table not found' });
  table.status = 'occupied';
  table.currentOrder = orderId;
  await table.save();
  res.json(table);
});

// free a table
router.post('/:id/free', async (req, res) => {
  const table = await Table.findById(req.params.id);
  if (!table) return res.status(404).json({ message: 'Table not found' });
  if (table.currentOrder) {
    const order = await Order.findById(table.currentOrder);
    if (order) {
      order.status = 'closed';
      await order.save();
    }
  }
  table.status = 'free';
  table.currentOrder = undefined;
  await table.save();
  res.json(table);
});

// create table
router.post('/', async (req, res) => {
  const { number, seats } = req.body;
  const t = new Table({ number, seats });
  await t.save();
  res.status(201).json(t);
});

module.exports = router;
