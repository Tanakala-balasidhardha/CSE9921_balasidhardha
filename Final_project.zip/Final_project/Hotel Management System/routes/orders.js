const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const Table = require('../models/Table');
const MenuItem = require('../models/MenuItem');

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// create order
router.post('/', async (req, res) => {
  try {
    const { customerId, customerName, tableId, tableNumber, items } = req.body;
    if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ message: 'items required' });

    let customerRef = customerId;
    if (!customerRef && customerName) {
      const customer = await Customer.findOne({ name: customerName });
      if (!customer) return res.status(400).json({ message: `customer ${customerName} not found` });
      customerRef = customer._id;
    }

    let tableRef = tableId;
    if (!tableRef && tableNumber !== undefined && tableNumber !== null) {
      const table = await Table.findOne({ number: tableNumber });
      if (!table) return res.status(400).json({ message: `table ${tableNumber} not found` });
      tableRef = table._id;
    }

    if (customerRef && !isValidObjectId(customerRef)) {
      return res.status(400).json({ message: 'Invalid customer ID or name' });
    }
    if (tableRef && !isValidObjectId(tableRef)) {
      return res.status(400).json({ message: 'Invalid table number or ID' });
    }

    // build order items with price
    const orderItems = [];
    let total = 0;
    for (const it of items) {
      let menu;
      if (typeof it.menuItem === 'string') {
        if (isValidObjectId(it.menuItem)) {
          menu = await MenuItem.findById(it.menuItem);
        }
        if (!menu) {
          menu = await MenuItem.findOne({ name: it.menuItem });
        }
      } else if (it.menuItem && typeof it.menuItem === 'object' && isValidObjectId(it.menuItem._id)) {
        menu = await MenuItem.findById(it.menuItem._id);
      }

      if (!menu) return res.status(400).json({ message: `menuItem ${it.menuItem} not found` });

      const price = menu.price;
      const qty = it.qty || 1;
      orderItems.push({ menuItem: menu._id, qty, price });
      total += price * qty;
    }

    const order = new Order({ customer: customerRef, table: tableRef, items: orderItems, total });
    await order.save();

    // mark table occupied
    if (tableRef) {
      const table = await Table.findById(tableRef);
      if (table) {
        table.status = 'occupied';
        table.currentOrder = order._id;
        await table.save();
      }
    }

    // add visit to customer
    if (customerRef) {
      const customer = await Customer.findById(customerRef);
      if (customer) {
        customer.visits.push(order._id);
        await customer.save();
      }
    }

    res.status(201).json(order);
  } catch (err) {
    console.error('Order create error:', err);
    res.status(500).json({ message: 'Internal server error', error: err.message });
  }
});

// get order
router.get('/:id', async (req, res) => {
  const order = await Order.findById(req.params.id).populate('items.menuItem').populate('customer').populate('table');
  if (!order) return res.status(404).json({ message: 'Order not found' });
  res.json(order);
});

// close order (pay)
router.post('/:id/close', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  order.status = 'closed';
  await order.save();
  // free table if assigned
  if (order.table) {
    const table = await Table.findById(order.table);
    if (table) {
      table.status = 'free';
      table.currentOrder = undefined;
      await table.save();
    }
  }
  res.json(order);
});

// delete order
router.delete('/:id', async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });

  if (order.table) {
    const table = await Table.findById(order.table);
    if (table) {
      table.status = 'free';
      table.currentOrder = undefined;
      await table.save();
    }
  }

  if (order.customer) {
    const customer = await Customer.findById(order.customer);
    if (customer) {
      customer.visits = customer.visits.filter(v => v.toString() !== order._id.toString());
      await customer.save();
    }
  }

  await Order.findByIdAndDelete(req.params.id);
  res.status(204).end();
});

module.exports = router;
