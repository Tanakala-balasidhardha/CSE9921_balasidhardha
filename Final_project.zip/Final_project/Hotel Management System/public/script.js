const API = 'http://localhost:3000/api';

// Initialize
window.addEventListener('DOMContentLoaded', () => {
  setupTabs();
  loadAll();
  setInterval(loadAll, 5000);
});

// Tab switching
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
      if (btn.dataset.tab === 'orders') loadOrders();
      if (btn.dataset.tab === 'tables') loadTables();
    });
  });
}

async function loadAll() {
  loadMenu();
  loadTables();
  loadCustomers();
  loadOrders();
}

// Menu
async function loadMenu() {
  try {
    const res = await fetch(`${API}/menu`);
    const items = await res.json();
    document.getElementById('menuList').innerHTML = items.map(item => `
      <div class="item">
        <div class="item-info">
          <div class="item-title">${item.name}</div>
          <div class="item-text">${item.description || 'N/A'}</div>
          <div class="item-text" style="color: #28a745; font-weight: 600;">₹${item.price}</div>
        </div>
        <div class="item-actions">
          <button class="btn-small" onclick="deleteMenuItem('${item._id}')">Delete</button>
        </div>
      </div>
    `).join('');
    
    // Populate order menu dropdown
    const select = document.getElementById('orderMenuItem');
    select.innerHTML = '<option>Select Menu Item...</option>' + items.map(item => 
      `<option value="${item._id}">${item.name} (₹${item.price})</option>`
    ).join('');
  } catch (e) {
    console.error('Menu load error:', e);
    updateStatus('❌ Failed to load menu');
  }
}

async function addMenuItem() {
  const name = document.getElementById('menuName').value;
  const price = parseFloat(document.getElementById('menuPrice').value);
  const desc = document.getElementById('menuDesc').value;
  if (!name || !price) return alert('Name and price required');
  
  try {
    const res = await fetch(`${API}/menu`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, price, description: desc, available: true })
    });
    if (!res.ok) throw new Error('Failed to add');
    document.getElementById('menuName').value = '';
    document.getElementById('menuPrice').value = '';
    document.getElementById('menuDesc').value = '';
    updateStatus('✅ Menu item added');
    loadMenu();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

async function deleteMenuItem(id) {
  if (!confirm('Delete this item?')) return;
  try {
    await fetch(`${API}/menu/${id}`, { method: 'DELETE' });
    updateStatus('✅ Menu item deleted');
    loadMenu();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

// Tables
async function loadTables() {
  try {
    const res = await fetch(`${API}/tables`);
    const tables = await res.json();
    
    // Status summary
    const status = await fetch(`${API}/tables/status`).then(r => r.json());
    document.getElementById('statusSummary').innerHTML = `
      📊 Total: ${status.total} | Free: ${status.freeTables} | Occupied: ${status.occupied}
      ${status.allFilled ? '⚠️ All tables filled!' : ''}
    `;
    
    document.getElementById('tableList').innerHTML = tables.map(t => `
      <div class="item">
        <div class="item-info">
          <div class="item-title">Table ${t.number}</div>
          <div class="item-text">Seats: ${t.seats}</div>
          <div class="item-text">Status: <span class="item-status ${t.status === 'free' ? 'status-free' : 'status-occupied'}">${t.status.toUpperCase()}</span></div>
        </div>
        <div class="item-actions">
          <button class="btn-small" onclick="deleteTable('${t._id}')">Delete</button>
        </div>
      </div>
    `).join('');
    
    // Populate order table dropdown
    const select = document.getElementById('orderTable');
    select.innerHTML = '<option>Select Table...</option>' + tables.map(t => 
      `<option value="${t._id}">Table ${t.number}</option>`
    ).join('');
  } catch (e) {
    console.error('Tables load error:', e);
    updateStatus('❌ Failed to load tables');
  }
}

async function addTable() {
  const number = parseInt(document.getElementById('tableNo').value);
  const seats = parseInt(document.getElementById('tableSeats').value) || 4;
  if (!number) return alert('Table number required');
  
  try {
    const res = await fetch(`${API}/tables`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number, seats })
    });
    if (!res.ok) throw new Error('Failed to add');
    document.getElementById('tableNo').value = '';
    document.getElementById('tableSeats').value = '';
    updateStatus('✅ Table created');
    loadTables();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

async function deleteTable(id) {
  if (!confirm('Delete this table?')) return;
  try {
    await fetch(`${API}/tables/${id}`, { method: 'DELETE' });
    updateStatus('✅ Table deleted');
    loadTables();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

// Customers
async function loadCustomers() {
  try {
    const res = await fetch(`${API}/customers`);
    const customers = await res.json();
    document.getElementById('customerList').innerHTML = customers.map(c => `
      <div class="item">
        <div class="item-info">
          <div class="item-title">${c.name}</div>
          <div class="item-text">${c.email || 'No email'}</div>
          <div class="item-text">Visits: ${c.visits.length}</div>
        </div>
        <div class="item-actions">
          <button class="btn-small" onclick="viewCustomerHistory('${c._id}')">History</button>
        </div>
      </div>
    `).join('');
    
    // Populate order customer dropdown
    const select = document.getElementById('orderCustomer');
    select.innerHTML = '<option>Select Customer...</option>' + customers.map(c => 
      `<option value="${c._id}">${c.name}</option>`
    ).join('');
  } catch (e) {
    console.error('Customers load error:', e);
  }
}

async function addCustomer() {
  const name = document.getElementById('custName').value;
  const email = document.getElementById('custEmail').value;
  if (!name) return alert('Name required');
  
  try {
    const res = await fetch(`${API}/customers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email })
    });
    if (!res.ok) throw new Error('Failed to add');
    document.getElementById('custName').value = '';
    document.getElementById('custEmail').value = '';
    updateStatus('✅ Customer added');
    loadCustomers();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

async function viewCustomerHistory(id) {
  try {
    const res = await fetch(`${API}/customers/${id}`);
    const data = await res.json();
    const c = data.customer;
    const orders = data.orders || [];
    const total = orders.reduce((sum, o) => sum + o.total, 0);
    alert(`${c.name}\nEmail: ${c.email}\nVisits: ${c.visits.length}\nTotal Spent: ₹${total}`);
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

// Orders
let currentOrderItems = [];

function addOrderItem() {
  const custId = document.getElementById('orderCustomer').value;
  const tableId = document.getElementById('orderTable').value;
  const menuId = document.getElementById('orderMenuItem').value;
  const qty = parseInt(document.getElementById('orderQty').value) || 1;
  
  if (!custId || custId === 'Select Customer...') return alert('Select customer');
  if (!tableId || tableId === 'Select Table...') return alert('Select table');
  if (!menuId || menuId === 'Select Menu Item...') return alert('Select menu item');
  
  currentOrderItems.push({ menuItem: menuId, qty });
  
  // Get menu item name
  fetch(`${API}/menu`).then(r => r.json()).then(items => {
    const item = items.find(i => i._id === menuId);
    if (item) {
      const preview = document.getElementById('orderItemsPreview');
      preview.innerHTML += `<div class="item-group">${item.name} x${qty} (₹${item.price * qty})</div>`;
    }
  });
  
  document.getElementById('createOrderBtn').style.display = 'block';
  document.getElementById('orderQty').value = '1';
}

async function createOrder() {
  const custId = document.getElementById('orderCustomer').value;
  const tableId = document.getElementById('orderTable').value;
  
  if (currentOrderItems.length === 0) return alert('Add items to order');
  if (!custId) return alert('Select customer');
  if (!tableId) return alert('Select table');
  
  try {
    const res = await fetch(`${API}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customerId: custId, tableId, items: currentOrderItems })
    });
    if (!res.ok) {
      const errorBody = await res.json().catch(() => null);
      const message = errorBody?.message || 'Failed to create order';
      throw new Error(message);
    }
    
    currentOrderItems = [];
    document.getElementById('orderItemsPreview').innerHTML = '';
    document.getElementById('createOrderBtn').style.display = 'none';
    document.getElementById('orderCustomer').value = '';
    document.getElementById('orderTable').value = '';
    document.getElementById('orderMenuItem').value = '';
    document.getElementById('orderQty').value = '1';
    updateStatus('✅ Order created');
    loadOrders();
    loadTables();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

async function loadOrders() {
  try {
    const res = await fetch(`${API}/tables`);
    const tables = await res.json();
    
    const orders = [];
    for (const t of tables) {
      if (t.currentOrder) {
        const orderId = typeof t.currentOrder === 'object' ? t.currentOrder._id : t.currentOrder;
        if (!orderId) continue;
        const ores = await fetch(`${API}/orders/${orderId}`);
        if (ores.ok) {
          const order = await ores.json();
          orders.push(order);
        }
      }
    }
    
    document.getElementById('orderList').innerHTML = orders.length === 0 
      ? '<p>No open orders</p>'
      : orders.map(o => `
        <div class="item">
          <div class="item-info">
            <div class="item-title">Order #${o._id.slice(-6)}</div>
            <div class="item-text">Table: ${o.table?.number || 'N/A'}</div>
            <div class="item-text">Customer: ${o.customer?.name || 'Walk-in'}</div>
            <div class="item-text">Total: ₹${o.total}</div>
          </div>
          <div class="item-actions">
            <button class="btn-small success" onclick="closeOrder('${o._id}')">Pay & Close</button>
          </div>
        </div>
      `).join('');
  } catch (e) {
    console.error('Orders load error:', e);
  }
}

async function closeOrder(id) {
  if (!confirm('Close order and free table?')) return;
  try {
    const res = await fetch(`${API}/orders/${id}/close`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to close');
    updateStatus('✅ Order closed and table freed');
    loadOrders();
    loadTables();
  } catch (e) {
    alert('Error: ' + e.message);
  }
}

function updateStatus(msg) {
  document.getElementById('status').textContent = msg;
  setTimeout(() => document.getElementById('status').textContent = '✅ Connected', 3000);
}
