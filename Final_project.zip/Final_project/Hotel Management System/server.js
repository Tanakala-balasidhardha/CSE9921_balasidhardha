const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

dotenv.config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/hotel_management';
const PORT = process.env.PORT || 3000;

// require models to ensure they're registered
require('./models/Customer');
require('./models/MenuItem');
require('./models/Table');
require('./models/Order');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// mount routes
app.use('/api/customers', require('./routes/customers'));
app.use('/api/menu', require('./routes/menu'));
app.use('/api/tables', require('./routes/tables'));
app.use('/api/orders', require('./routes/orders'));

app.get('/', (req, res) => res.send('Hotel Management System API'));

async function start() {
  try {
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  } catch (err) {
    console.error('Failed to start', err);
    process.exit(1);
  }
}

start();

module.exports = app;
