# Hotel Management System (Backend)

Simple Node.js + Express backend to manage menu, tables, customers and orders. Designed for local MongoDB and testing via Postman.

## Project Objective

To provide a streamlined backend API for hotel restaurants to manage menus, tables, customers, and orders efficiently with MongoDB persistence.

## Setup

1. Install dependencies

```bash
cd "~/Desktop/Hotel Management"
npm install
```

2. Configure MongoDB

Copy `.env.example` to `.env` and adjust `MONGO_URI` if needed. By default it points to `mongodb://127.0.0.1:27017/hotel_management`.

3. Run

```bash
npm run dev
```

API Endpoints (examples for Postman)

- GET `/` — health check

- Menu
  - GET `/api/menu` — list menu items
  - POST `/api/menu` — create { name, description, price }

- Tables
  - GET `/api/tables` — list tables
  - GET `/api/tables/status` — availability summary
  - POST `/api/tables` — create { number, seats }
  - POST `/api/tables/:id/occupy` — body { orderId }
  - POST `/api/tables/:id/free` — free table and close order

- Customers
  - POST `/api/customers` — create customer { name, email? }
  - GET `/api/customers` — list
  - GET `/api/customers/:id` — customer and order history

- Orders
  - POST `/api/orders` — create order { customerId, tableId, items: [{ menuItem, qty }] }
  - GET `/api/orders/:id` — get order details
  - POST `/api/orders/:id/close` — close (pay) order and free table

Testing in Postman

1. Create menu items via POST `/api/menu`.
2. Create tables via POST `/api/tables`.
3. Create a customer via POST `/api/customers`.
4. Create an order via POST `/api/orders` with `customerId`, `tableId`, and `items` referencing created `menuItem` ids.
5. Close the order via POST `/api/orders/:id/close` to simulate payment and free the table.
